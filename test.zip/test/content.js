// ============================================================
// SHLX LMS Auto Interaction - Content Script (v5)
// Đa trang: danh-sach-mon-hoc → mon-hoc → bai-hoc
// Theo dõi tiến độ %, đạt 70-80% thì chuyển bài/môn khác
// ============================================================
(function () {
  'use strict';

  const CFG = {
    progressSwitchMin: 70, progressSwitchMax: 80,
    courseMinPct: 70, lessonMinPct: 70,
    progressCheckInterval: 5000, touchIntervalMin: 10000, touchIntervalMax: 25000,
    scrollBetweenMin: 8000, scrollBetweenMax: 15000,
    clickDelay: 1500, contentLoadDelay: 3000,
    dialogPollInterval: 500, dialogMaxWait: 5000,
    skipKeywords: ['lời mở đầu', 'bỏ lời', 'bỏ qua', 'skip intro', 'skip'],
    stallCheckMinutes: 15,  // kiểm tra % có tăng sau 15 phút không
  };

  let isRunning = false, observer = null, lessonTimers = { progress: null, touch: null, stall: null };
  let lessonStartProgress = -1, lessonStartTime = 0;

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
  function log(...args) { console.log('[SHLX]', new Date().toLocaleTimeString(), ...args); }

  // ============================================================
  // TOAST + BADGE
  // ============================================================
  function showToast(msg, dur) {
    const old = document.getElementById('__shlx_toast__'); if (old) old.remove();
    const t = document.createElement('div'); t.id = '__shlx_toast__'; t.textContent = msg;
    Object.assign(t.style, { position:'fixed', bottom:'20px', right:'20px', zIndex:'99999', background:'#0077cc', color:'#fff', padding:'10px 20px', borderRadius:'8px', fontSize:'13px', fontWeight:'600', fontFamily:'sans-serif', boxShadow:'0 4px 12px rgba(0,0,0,0.3)', transition:'opacity 0.3s', pointerEvents:'none' });
    document.body.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; setTimeout(() => t.remove(), 300); }, dur || 2000);
  }
  function showBadge(show) {
    const old = document.getElementById('__shlx_badge__'); if (old) old.remove();
    if (!show) return;
    const b = document.createElement('div'); b.id = '__shlx_badge__'; b.textContent = '● AUTO';
    Object.assign(b.style, { position:'fixed', top:'10px', right:'10px', zIndex:'99999', background:'#00bfb3', color:'#fff', padding:'4px 10px', borderRadius:'12px', fontSize:'11px', fontWeight:'700', fontFamily:'sans-serif', boxShadow:'0 2px 8px rgba(0,0,0,0.3)', animation:'shlxPulse 2s infinite' });
    const s = document.createElement('style'); s.textContent = '@keyframes shlxPulse{0%,100%{opacity:1}50%{opacity:.5}}'; document.head.appendChild(s);
    document.body.appendChild(b);
  }

  // Progress/stall info bar (hiển thị trên bài học)
  function showProgressBar(show, text, warning) {
    const old = document.getElementById('__shlx_prog_bar__'); if (old) old.remove();
    if (!show) return;
    const bar = document.createElement('div'); bar.id = '__shlx_prog_bar__'; bar.textContent = text || '';
    Object.assign(bar.style, {
      position:'fixed', bottom:'4px', left:'0', right:'0', zIndex:'99998',
      background: warning ? '#bd271e' : '#1a1c21', color:'#fff',
      padding:'6px 12px', fontSize:'11px', fontWeight:'600', fontFamily:'sans-serif',
      textAlign:'center', opacity:'0.92', pointerEvents:'none',
    });
    document.body.appendChild(bar);
  }

  // ============================================================
  // EVENT SIMULATION
  // ============================================================
  function fireAllEvents(el, x, y) {
    if (!el) return;
    try { el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, clientX: x, clientY: y, pointerId: 1, pointerType: 'mouse', isPrimary: true })); } catch(e) {}
    try { el.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, clientX: x, clientY: y, pointerId: 1, pointerType: 'mouse', isPrimary: true })); } catch(e) {}
    try { el.dispatchEvent(new MouseEvent('mousedown', { view: window, bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0 })); } catch(e) {}
    try { el.dispatchEvent(new MouseEvent('mouseup', { view: window, bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0 })); } catch(e) {}
    try { el.dispatchEvent(new MouseEvent('click', { view: window, bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0 })); } catch(e) {}
  }
  function clickEl(el) {
    if (!el) { log('clickEl: null'); return false; }
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    log('  Click:', (el.textContent || '').trim().substring(0, 60));
    el.focus({ preventScroll: false }); el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    fireAllEvents(el, cx, cy);
    try { el.click(); } catch(e) {}
    return true;
  }

  // ============================================================
  // FIND ELEMENTS
  // ============================================================
  function findSidebar() { return document.querySelector('[class*="euiPageSidebar"]') || document.querySelector('.euiPageSidebar'); }
  function findMainContent() { return document.querySelector('.euiPageBody') || document.querySelector('[class*="euiPageBody"]') || document.querySelector('main'); }
  function findProgressBar() { return document.querySelector('progress.euiProgress'); }

  // ============================================================
  // PAGE TYPE
  // ============================================================
  function detectPageType() {
    if (document.querySelector('progress.euiProgress')) return 'lesson';
    const cards = document.querySelectorAll('[class*="euiCard"]');
    if (cards.length >= 3) return 'course-list';
    const links = document.querySelectorAll('button[class*="euiLink"]');
    if (links.length >= 5) return 'course-detail';
    const url = location.href;
    if (url.includes('/courses') && !url.includes('/course-items')) return 'course-list';
    if (url.includes('/course-items')) return 'lesson';
    return 'unknown';
  }

  // ============================================================
  // SAFETY
  // ============================================================
  function isSafeToClick(el) {
    if (!el) return false;
    if (el.tagName === 'A') return false;
    if (el.closest('[class*="euiPageSidebar"]') || el.closest('.euiPageSidebar')) return false;
    if (el.closest('.euiBreadcrumbs') || el.closest('[class*="Breadcrumb"]')) return false;
    if (el.closest('.euiHeader') || el.closest('header')) return false;
    if (el.closest('[role="tablist"]') || el.closest('.euiTabs') || el.getAttribute('role') === 'tab') return false;
    if (el.closest('button[class*="euiLink"]')) return false;
    if (el.closest('#__shlx_panel__') || el.closest('#__shlx_float_') || el.closest('#__shlx_overlay_')) return false;
    let cur = el;
    for (let i = 0; i < 5; i++) { if (!cur || cur === document.body) break; if (cur.tagName === 'A' && cur.href) return false; cur = cur.parentElement; }
    return true;
  }

  // ============================================================
  // SCROLL + TOUCH
  // ============================================================
  async function slowScroll(el, target, dur) {
    const start = el.scrollTop, dist = target - start;
    if (Math.abs(dist) < 5) { el.scrollTop = target; return; }
    const t0 = performance.now();
    return new Promise(resolve => {
      function step() {
        const p = Math.min((performance.now() - t0) / dur, 1);
        el.scrollTop = start + dist * (p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2);
        p < 1 ? requestAnimationFrame(step) : resolve();
      }
      requestAnimationFrame(step);
    });
  }

  async function scrollAndTouch() {
    const content = findMainContent(), sidebar = findSidebar();
    let safeLeft = 0, safeRight = window.innerWidth;
    if (sidebar) {
      const sr = sidebar.getBoundingClientRect();
      if (sr.width > 0 && sr.left < window.innerWidth / 2) safeLeft = sr.right + 20;
      else if (sr.left > window.innerWidth / 2) safeRight = sr.left - 20;
    }
    for (let i = 0; i < 3; i++) {
      if (content && content.scrollHeight > content.clientHeight) {
        const max = content.scrollHeight - content.clientHeight;
        await slowScroll(content, rand(0, Math.max(0, max)), rand(3000, 6000));
      } else {
        const max = Math.max(0, document.body.scrollHeight - window.innerHeight);
        await slowScroll(document.scrollingElement || document.documentElement, rand(0, max), rand(3000, 6000));
      }
      await sleep(rand(1000, 2000));
      const x = rand(Math.max(safeLeft, 50), Math.min(safeRight, window.innerWidth - 50));
      const y = rand(150, window.innerHeight - 150);
      const target = document.elementFromPoint(x, y);
      if (target && target !== document.body && target !== document.documentElement && isSafeToClick(target)) {
        fireAllEvents(target, x, y);
        if (Math.random() > 0.3) try { target.click(); } catch(e) {}
      }
    }
  }

  async function touchRandom() {
    const sidebar = findSidebar();
    let safeLeft = 0, safeRight = window.innerWidth;
    if (sidebar) {
      const sr = sidebar.getBoundingClientRect();
      if (sr.width > 0 && sr.left < window.innerWidth / 2) safeLeft = sr.right + 20;
      else if (sr.left > window.innerWidth / 2) safeRight = sr.left - 20;
    }
    const x = rand(Math.max(safeLeft, 200), Math.min(safeRight, window.innerWidth - 200));
    const y = rand(150, window.innerHeight - 150);
    const target = document.elementFromPoint(x, y);
    if (!target || target === document.body || target === document.documentElement || !isSafeToClick(target)) return;
    fireAllEvents(target, x, y);
    if (Math.random() > 0.5) {
      const area = findMainContent();
      const el = (area && area.scrollHeight > area.clientHeight) ? area : (document.scrollingElement || document.documentElement);
      const max = el.scrollHeight - el.clientHeight;
      slowScroll(el, rand(Math.max(0, el.scrollTop - 200), Math.min(max, el.scrollTop + 200)), rand(2000, 4000));
    }
    if (Math.random() > 0.4 && isSafeToClick(target)) try { target.click(); } catch(e) {}
  }

  // ============================================================
  // VIDEO
  // ============================================================
  function findVideo() {
    return document.querySelector('iframe[src*="youtube"], iframe[src*="youtu.be"]') ||
           document.querySelector('video') || document.querySelector('iframe[src*="video"]');
  }
  function clickPlayVideo() {
    const iframe = document.querySelector('iframe[src*="youtube"]');
    if (iframe) {
      const r = iframe.getBoundingClientRect();
      fireAllEvents(iframe, r.left + r.width / 2, r.top + r.height / 2);
      try { iframe.contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', '*'); } catch(e) {}
      return true;
    }
    const video = document.querySelector('video');
    if (video) { try { video.play(); } catch(e) {} fireAllEvents(video, video.getBoundingClientRect().left + 100, video.getBoundingClientRect().top + 100); return true; }
    const playBtn = document.querySelector('[class*="play"], [class*="Play"], [aria-label*="play"], [aria-label*="Play"]');
    if (playBtn) { clickEl(playBtn); return true; }
    return false;
  }

  // ============================================================
  // DIALOG + AUTO AGREE (tìm "đồng ý" không phân biệt hoa/thường)
  // ============================================================
  function findAgreeButton() {
    const all = document.querySelectorAll('button, [role="button"], a, span, div');
    for (const el of all) {
      const text = (el.textContent || '').toLowerCase().trim();
      if (text.includes('đồng ý') || text.includes('dong y') || text.includes('đồng ý')) {
        // Ưu tiên button
        if (el.tagName === 'BUTTON') return el;
        const btn = el.closest('button');
        if (btn) return btn;
        if (el.click && el.getAttribute('role') === 'button') return el;
        return el;
      }
    }
    return null;
  }

  async function handleDialog() {
    const start = Date.now();
    while (Date.now() - start < CFG.dialogMaxWait) {
      const agree = findAgreeButton();
      if (agree) { log('Click Đồng ý (from dialog)'); clickEl(agree); await sleep(CFG.clickDelay); return true; }
      await sleep(CFG.dialogPollInterval);
    }
    return false;
  }

  // Chạy sau mỗi lần click vào sidebar item / load lại trang
  async function autoAgreeAfterDelay(delayMs) {
    await sleep(delayMs || 20000);
    const agree = findAgreeButton();
    if (agree) { log('Auto-agree: found "đồng ý", clicking'); showToast('Tự động click Đồng ý', 1500); clickEl(agree); return true; }
    return false;
  }

  // Watcher chạy ngầm: mỗi 20s sau khi load/click, kiểm tra "đồng ý"
  let agreeWatcherTimer = null;
  function startAgreeWatcher() {
    if (agreeWatcherTimer) clearInterval(agreeWatcherTimer);
    agreeWatcherTimer = setInterval(() => {
      if (!isRunning) return;
      const agree = findAgreeButton();
      if (agree) { log('AgreeWatcher: found "đồng ý", clicking'); clickEl(agree); }
    }, 20000);
  }
  function stopAgreeWatcher() {
    if (agreeWatcherTimer) { clearInterval(agreeWatcherTimer); agreeWatcherTimer = null; }
  }

  // ============================================================
  // COURSE LIST PAGE
  // ============================================================
  function getCourseCards() {
    const cards = [];
    const allElements = document.querySelectorAll('button, [role="button"], [class*="euiCard"], [class*="Card"]');
    for (const el of allElements) {
      const text = (el.textContent || '').trim();
      const pctMatch = text.match(/\((\d+)%\)/);
      if (!pctMatch) continue;
      const pct = parseInt(pctMatch[1]);
      const name = text.split('Thời gian học')[0]?.trim() || text.substring(0, 50);
      cards.push({ el, text: name, pct });
    }
    const seen = new Set();
    return cards.filter(c => { const k = c.text + c.pct; if (seen.has(k)) return false; seen.add(k); return true; });
  }

  async function handleCourseListPage() {
    log('=== COURSE LIST ===');
    showToast('Đang quét danh sách môn học...', 2000);
    await sleep(2000);
    const cards = getCourseCards();
    log(`Found ${cards.length} courses`);
    cards.forEach(c => log(`  ${c.text.substring(0,40)}: ${c.pct}%`));
    const below = cards.filter(c => c.pct < CFG.courseMinPct);
    if (below.length === 0) {
      log('All courses >= 70%!');
      showToast('Tất cả môn học đã >= 70%!', 5000);
      return;
    }
    log(`Clicking: ${below[0].text.substring(0,40)} (${below[0].pct}%)`);
    showToast(`Vào môn: ${below[0].text.substring(0,30)} (${below[0].pct}%)`, 3000);
    let clickable = below[0].el;
    let cur = clickable;
    for (let i = 0; i < 10; i++) {
      if (!cur || cur === document.body) break;
      if (cur.tagName === 'BUTTON' || cur.getAttribute('role') === 'button' || cur.onclick || cur.className.includes('euiCard')) { clickable = cur; break; }
      cur = cur.parentElement;
    }
    clickEl(clickable);
    autoAgreeAfterDelay(20000); // kiểm tra "đồng ý" sau 20s
  }

  // ============================================================
  // COURSE DETAIL PAGE
  // ============================================================
  function getLessonItems() {
    const items = [];
    const buttons = document.querySelectorAll('button[class*="euiLink"]');
    for (const btn of buttons) {
      const text = (btn.textContent || '').trim();
      if (text.length < 3) continue;
      const parentText = (btn.parentElement?.parentElement?.textContent || text).trim();
      const pctMatch = parentText.match(/(\d+)%/);
      const name = text.split('Thời gian')[0]?.trim() || text;
      const pct = pctMatch ? parseInt(pctMatch[1]) : -1;
      const isIntro = CFG.skipKeywords.some(kw => name.toLowerCase().includes(kw.toLowerCase()));
      const successIcon = btn.querySelector('svg[class*="euiIcon-success"]');
      items.push({ el: btn, text: name, pct, isIntro, hasCheckmark: !!successIcon });
    }
    const seen = new Set();
    return items.filter(i => { const k = i.text + i.pct; if (seen.has(k)) return false; seen.add(k); return true; });
  }

  async function handleCourseDetailPage() {
    log('=== COURSE DETAIL ===');
    showToast('Đang quét danh sách bài học...', 2000);
    await sleep(2000);
    let items = getLessonItems();
    if (items.length === 0) { await sleep(3000); items = getLessonItems(); }
    log(`Found ${items.length} lessons`);
    items.forEach(it => log(`  ${it.pct}% ${it.isIntro?'[I]':''} ${it.hasCheckmark?'[✓]':''} "${it.text.substring(0,50)}"`));
    const below = items.filter(it => !it.isIntro && it.pct >= 0 && it.pct < CFG.lessonMinPct);
    if (below.length === 0) {
      log('All lessons >= 70%!');
      showToast('Tất cả bài học đã >= 70%! Quay lại...', 3000);
      goBackToCourseList();
      return;
    }

    // Bỏ qua bài đã bị skip (stall)
    const skippedNames = getSkippedLessons().map(s => s.name);
    const available = below.filter(it => !skippedNames.includes(it.text));
    const chosen = available.length > 0 ? available[0] : below[0];
    if (available.length === 0) {
      log('All below-70% lessons were skipped due to stall, retrying first one');
    }

    log(`Clicking: ${chosen.text.substring(0,40)} (${chosen.pct}%)`);
    showToast(`Vào bài: ${chosen.text.substring(0,30)} (${chosen.pct}%)`, 3000);
    clickEl(chosen.el);
    autoAgreeAfterDelay(20000);
  }

  // ============================================================
  // LESSON PAGE
  // ============================================================
  function getSidebarItems() {
    const sidebar = findSidebar();
    if (!sidebar) return [];
    const items = [];
    sidebar.querySelectorAll('button[class*="euiLink"]').forEach(btn => {
      const text = (btn.textContent || '').trim();
      if (!text || text.length < 2) return;
      let isActive = btn.className.includes('euiLink-accent') || btn.className.includes('Accent');
      if (!isActive) { const color = window.getComputedStyle(btn).color; if (color === 'rgb(186, 61, 118)' || color === '#ba3d76') isActive = true; }
      items.push({ el: btn, text, isActive, isCompleted: !!btn.querySelector('svg[class*="euiIcon-success"]'), isIntro: CFG.skipKeywords.some(kw => text.toLowerCase().includes(kw.toLowerCase())) });
    });
    return items;
  }

  function findNextUnchecked(items, idx) {
    for (let i = idx + 1; i < items.length; i++) if (!items[i].isCompleted && !items[i].isIntro) return { item: items[i], idx: i };
    for (let i = 0; i <= idx; i++) if (!items[i].isCompleted && !items[i].isIntro && !items[i].isActive) return { item: items[i], idx: i };
    return null;
  }

  async function skipIntro() {
    let items = getSidebarItems();
    if (!items.length) { await sleep(2000); items = getSidebarItems(); }
    if (!items.length) return false;
    for (let i = 0; i < items.length; i++) {
      if (!items[i].isIntro) continue;
      if (items[i].isActive) { if (i + 1 < items.length) { clickEl(items[i + 1].el); await handleDialog(); return true; } }
      clickEl(items[i].el); await sleep(3000);
      items = getSidebarItems();
      const ai = items.findIndex(it => it.isActive);
      if (ai >= 0 && ai + 1 < items.length) { clickEl(items[ai + 1].el); await handleDialog(); }
      return true;
    }
    return false;
  }

  async function switchToNextUnchecked() {
    let items = getSidebarItems();
    if (!items.length) { await sleep(2000); items = getSidebarItems(); }
    if (!items.length) return false;
    const activeIdx = items.findIndex(it => it.isActive);
    if (activeIdx < 0) return false;
    const next = findNextUnchecked(items, activeIdx);
    if (!next) return false;
    log(`Switch to: ${next.item.text.substring(0,40)}`);
    showToast(`Chuyển: ${next.item.text.substring(0,35)}`, 2000);
    clickEl(next.item.el);
    await handleDialog();
    await sleep(CFG.contentLoadDelay);
    return true;
  }

  function getProgressPercent() {
    const bar = findProgressBar();
    if (!bar) return -1;
    const val = parseFloat(bar.getAttribute('value')), max = parseFloat(bar.getAttribute('max')) || 100;
    return isNaN(val) ? -1 : Math.round((val / max) * 100);
  }

  function goBackToCourseDetail() {
    const breadcrumbs = document.querySelectorAll('.euiBreadcrumbs button, [class*="Breadcrumb"] button');
    if (breadcrumbs.length >= 2) { clickEl(breadcrumbs[1]); }
    else if (breadcrumbs.length >= 1) { clickEl(breadcrumbs[0]); }
    else { history.back(); }
    autoAgreeAfterDelay(20000);
  }

  function goBackToCourseList() {
    const breadcrumbs = document.querySelectorAll('.euiBreadcrumbs button, [class*="Breadcrumb"] button');
    if (breadcrumbs.length >= 1) { clickEl(breadcrumbs[0]); }
    else { history.back(); }
    autoAgreeAfterDelay(20000);
  }

  async function checkProgressAndSwitch() {
    if (!isRunning) return;
    const pct = getProgressPercent();
    if (pct < 0) {
      const m = document.body.textContent.match(/(\d+)%/);
      if (m) { const v = parseInt(m[1]); if (!isNaN(v) && v >= CFG.progressSwitchMin && v <= CFG.progressSwitchMax) { showToast(`Đạt ${v}%, quay lại...`, 2000); goBackToCourseDetail(); } }
      return;
    }
    if (pct >= CFG.progressSwitchMin && pct <= CFG.progressSwitchMax) { showToast(`Đạt ${pct}%, quay lại...`, 2000); goBackToCourseDetail(); }
  }

  // ============================================================
  // STALL DETECTION & SKIPPED LESSONS
  // ============================================================
  function getSkippedLessons() {
    try { return JSON.parse(localStorage.getItem('shlx_skipped') || '[]'); } catch(e) { return []; }
  }
  function addSkippedLesson(name) {
    const list = getSkippedLessons();
    list.push({ name, time: Date.now() });
    try { localStorage.setItem('shlx_skipped', JSON.stringify(list)); } catch(e) {}
    log(`Skipped lessons: ${list.length}`);
  }
  function isLessonSkipped(name) {
    return getSkippedLessons().some(s => s.name === name);
  }

  function getCurrentLessonName() {
    // Lấy tên bài học từ breadcrumb cuối hoặc title
    const bc = document.querySelectorAll('.euiBreadcrumbs [class*="Breadcrumb"]');
    if (bc.length >= 2) return (bc[bc.length - 1].textContent || '').trim().substring(0, 80);
    const h1 = document.querySelector('h1');
    if (h1) return h1.textContent.trim().substring(0, 80);
    return 'unknown-lesson';
  }

  function checkProgressStall() {
    if (!isRunning || detectPageType() !== 'lesson') return;
    const nowPct = getProgressPercent();
    const elapsed = (Date.now() - lessonStartTime) / 60000;
    const lessonName = getCurrentLessonName();

    showProgressBar(true, `Tiến độ: ${nowPct}% | Bắt đầu: ${lessonStartProgress}% | ${Math.round(elapsed)}/${CFG.stallCheckMinutes} phút`, false);

    if (nowPct <= 0) return;

    if (elapsed >= CFG.stallCheckMinutes) {
      if (nowPct <= lessonStartProgress) {
        log(`STALL: progress stuck at ${nowPct}% after ${Math.round(elapsed)}min!`);
        showToast(`⚠ "${lessonName}" không tăng tiến độ sau ${CFG.stallCheckMinutes} phút! Bỏ qua...`, 5000);
        showProgressBar(true, `⚠ BỎ QUA: ${lessonName} (kẹt ở ${nowPct}% sau ${Math.round(elapsed)}ph)`, true);
        addSkippedLesson(lessonName);
        setTimeout(() => goBackToCourseDetail(), 2000);
      } else {
        lessonStartProgress = nowPct;
        lessonStartTime = Date.now();
        log(`Progress increased to ${nowPct}%, resetting stall timer`);
        showProgressBar(true, `Tiến độ tăng: ${nowPct}% ↑ | Reset timer ${CFG.stallCheckMinutes}ph`, false);
      }
    }
  }

  // ============================================================
  // LESSON MAIN LOOP
  // ============================================================
  async function lessonMainLoop() {
    log('=== LESSON ===');
    showToast('Bài học - tương tác...', 2000); showBadge(true);
    await sleep(2000);
    await skipIntro(); await sleep(2000);
    if (findVideo()) { log('Video detected'); clickPlayVideo(); await sleep(1000); }
    // Kiểm tra "đồng ý" sau khi load trang bài học
    autoAgreeAfterDelay(20000);

    // Ghi nhận % lúc bắt đầu để phát hiện stall
    lessonStartProgress = getProgressPercent();
    lessonStartTime = Date.now();
    log(`Lesson start progress: ${lessonStartProgress}%`);

    lessonTimers.progress = setInterval(() => { if (!isRunning) { clearInterval(lessonTimers.progress); return; } checkProgressAndSwitch().catch(e => log('Prog err:', e.message)); }, CFG.progressCheckInterval);
    lessonTimers.stall = setInterval(() => { if (!isRunning) { clearInterval(lessonTimers.stall); return; } checkProgressStall(); }, 60000); // kiểm tra stall mỗi 1 phút
    (function scheduleTouch() { if (!isRunning) return; lessonTimers.touch = setTimeout(async () => { if (!isRunning) return; try { await touchRandom(); } catch(e) {} scheduleTouch(); }, rand(CFG.touchIntervalMin, CFG.touchIntervalMax)); })();

    while (isRunning && detectPageType() === 'lesson') {
      try { await scrollAndTouch(); } catch(e) { log('Scroll err:', e.message); }
      if (!isRunning || detectPageType() !== 'lesson') break;
      await sleep(rand(CFG.scrollBetweenMin, CFG.scrollBetweenMax));
    }
    clearInterval(lessonTimers.progress); clearTimeout(lessonTimers.touch); clearInterval(lessonTimers.stall);
    showProgressBar(false);
  }

  // ============================================================
  // OBSERVER
  // ============================================================
  function startObserver() {
    if (observer) observer.disconnect();
    observer = new MutationObserver(mutations => {
      if (!isRunning) return;
      for (const m of mutations) for (const node of m.addedNodes) {
        if (node.nodeType !== Node.ELEMENT_NODE) continue;
        const text = (node.textContent || '').toLowerCase();
        if (CFG.skipKeywords.some(kw => text.includes(kw.toLowerCase()))) { const btn = node.tagName === 'BUTTON' ? node : node.querySelector('button'); if (btn) clickEl(btn); }
        if (node.className && typeof node.className === 'string' && (node.className.includes('euiModal') || node.className.includes('Modal'))) { setTimeout(() => handleDialog(), 500); }
        if (node.querySelector) { const modal = node.querySelector('[class*="euiModal"]'); if (modal) setTimeout(() => handleDialog(), 500); }
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  // ============================================================
  // ROUTER
  // ============================================================
  async function runPageHandler() {
    const pt = detectPageType();
    log(`Page: ${pt}`);
    switch (pt) {
      case 'course-list': await handleCourseListPage(); break;
      case 'course-detail': await handleCourseDetailPage(); break;
      case 'lesson': await lessonMainLoop(); break;
    }
  }

  // ============================================================
  // START / STOP
  // ============================================================
  function start() { if (isRunning) return; isRunning = true; log('STARTED v5'); startObserver(); startAgreeWatcher(); showBadge(true); showToast('Auto v5: Bắt đầu!', 2000); try { localStorage.setItem('shlx_auto_running', '1'); } catch(e) {} runPageHandler().catch(e => log('Crash:', e.message)); }
  function stop() { isRunning = false; if (observer) { observer.disconnect(); observer = null; } clearInterval(lessonTimers.progress); clearTimeout(lessonTimers.touch); clearInterval(lessonTimers.stall); stopAgreeWatcher(); showProgressBar(false); log('STOPPED'); try { localStorage.setItem('shlx_auto_running', '0'); } catch(e) {} showBadge(false); showToast('Đã dừng', 2000); }

  // ============================================================
  // MESSAGE HANDLER
  // ============================================================
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    const actions = {
      ping: () => ({ pong: true, running: isRunning }),
      start: () => { start(); return { ok: true, running: true }; },
      stop: () => { stop(); return { ok: true, running: false }; },
      status: () => ({ ok: true, running: isRunning }),
      skipNow: () => skipIntro().then(r => ({ ok: r })),
      nextItem: () => switchToNextUnchecked().then(r => ({ ok: r })),
      scrollNow: () => scrollAndTouch().then(() => ({ ok: true })),
      touchNow: () => touchRandom().then(() => ({ ok: true })),
    };
    const fn = actions[msg.action];
    if (!fn) { sendResponse({ ok: false }); return; }
    const result = fn();
    if (result instanceof Promise) { result.then(r => { try { sendResponse(r); } catch(e) {} }); return true; }
    sendResponse(result);
  });

  // ============================================================
  // INIT
  // ============================================================
  log('Content script v5 loaded');
  try { if (localStorage.getItem('shlx_auto_running') === '1') { log('Auto-restart'); start(); } } catch(e) {}

  setTimeout(() => {
    const pt = detectPageType();
    log(`Detected: ${pt}`);
    if (pt === 'lesson') {
      getSidebarItems().forEach((it, i) => log(`  [${i}] ${it.isActive?'▶':' '} ${it.isCompleted?'✓':' '} "${it.text.substring(0,50)}"`));
      log(`Progress: ${getProgressPercent()}%, Video: ${!!findVideo()}`);
    }
    if (pt === 'course-list') getCourseCards().forEach(c => log(`  ${c.text.substring(0,40)}: ${c.pct}%`));
    if (pt === 'course-detail') getLessonItems().forEach(it => log(`  ${it.pct}% "${it.text.substring(0,50)}"`));
  }, 4000);
})();
