// Popup controller v3
// Dùng chrome.scripting.executeScript để đảm bảo luôn inject được

const btnToggle = document.getElementById('btnToggle');
const statusDot = document.getElementById('statusDot');
const statusLabel = document.getElementById('statusLabel');
const feedback = document.getElementById('feedback');

let isRunning = false;

function showFeedback(msg) {
  feedback.textContent = msg;
  setTimeout(() => { if (feedback.textContent === msg) feedback.textContent = ''; }, 3000);
}

// ============================================================
// Lấy tab hiện tại
// ============================================================
async function getCurrentTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

// ============================================================
// Đảm bảo content script đã được inject
// ============================================================
async function ensureContentScript(tabId) {
  // Thử gửi message trước
  try {
    const resp = await chrome.tabs.sendMessage(tabId, { action: 'ping' });
    if (resp && resp.pong) return true;
  } catch (e) {
    // Content script chưa có -> inject
  }

  showFeedback('Đang inject script...');

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content.js'],
    });
    // Đợi script khởi tạo
    await new Promise(r => setTimeout(r, 500));
    return true;
  } catch (e) {
    showFeedback('Không thể inject: ' + e.message);
    return false;
  }
}

// ============================================================
// Gửi action tới content script
// ============================================================
async function sendAction(action) {
  const tab = await getCurrentTab();
  if (!tab) { showFeedback('Không tìm thấy tab'); return null; }

  const ok = await ensureContentScript(tab.id);
  if (!ok) { showFeedback('Không inject được script'); return null; }

  try {
    const resp = await chrome.tabs.sendMessage(tab.id, { action });
    return resp;
  } catch (e) {
    showFeedback('Lỗi gửi lệnh: ' + e.message);
    return null;
  }
}

// ============================================================
// Gửi action và hiển thị kết quả
// ============================================================
async function doAction(action, label) {
  showFeedback(label + '...');
  const resp = await sendAction(action);
  if (resp) {
    showFeedback(resp.ok ? (label + ' - OK') : (label + ' - Không tìm thấy'));
  }
}

// ============================================================
// Check status
// ============================================================
async function checkStatus() {
  const tab = await getCurrentTab();
  if (!tab) return;

  try {
    const resp = await chrome.tabs.sendMessage(tab.id, { action: 'status' });
    if (resp) {
      updateToggleUI(resp.running);
      return;
    }
  } catch (e) {
    // Content script not loaded
  }
  updateToggleUI(false);
}

function updateToggleUI(running) {
  isRunning = running;
  if (running) {
    btnToggle.textContent = '⏹ Dừng Auto';
    btnToggle.classList.add('running');
    statusDot.classList.add('active');
    statusLabel.textContent = 'Auto đang chạy';
  } else {
    btnToggle.textContent = '▶ Bắt đầu Auto';
    btnToggle.classList.remove('running');
    statusDot.classList.remove('active');
    statusLabel.textContent = 'Auto đã dừng';
  }
}

// ============================================================
// Event handlers
// ============================================================
btnToggle.addEventListener('click', async () => {
  if (isRunning) {
    await doAction('stop', 'Đang dừng');
    updateToggleUI(false);
  } else {
    await doAction('start', 'Đang bắt đầu');
    updateToggleUI(true);
  }
});

document.getElementById('btnSkip').addEventListener('click', () => doAction('skipNow', 'Bỏ lời mở đầu'));
document.getElementById('btnNext').addEventListener('click', () => doAction('nextItem', 'Click mục tiếp theo'));
document.getElementById('btnTimeRange').addEventListener('click', () => doAction('timeRange', 'Duyệt 40-55 phút'));
document.getElementById('btnScroll').addEventListener('click', () => doAction('scrollNow', 'Scroll + chạm'));
document.getElementById('btnTouch').addEventListener('click', () => doAction('touchNow', 'Chạm ngẫu nhiên'));

// ============================================================
// Init
// ============================================================
checkStatus();
