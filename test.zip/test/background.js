// Background Service Worker - SHLX LMS Auto Interaction

chrome.runtime.onInstalled.addListener(() => {
  console.log('[SHLX Auto] Extension installed');
});

// Lắng nghe message từ popup để forward đến content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Nếu message từ popup, forward đến tab hiện tại
  if (message.from === 'popup') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, message, (response) => {
          sendResponse(response);
        });
      } else {
        sendResponse({ status: 'no_tab' });
      }
    });
    return true; // async
  }
});
